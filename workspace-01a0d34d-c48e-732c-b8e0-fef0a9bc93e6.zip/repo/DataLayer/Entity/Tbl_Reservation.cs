using DataLayer.Entity.BaseEntity;
using System.ComponentModel.DataAnnotations;

namespace DataLayer.Entity
{
    /// <summary>وضعیت نوبت</summary>
    public enum ReservationStatus
    {
        [Display(Name = "در انتظار تأیید")] Pending = 0,
        [Display(Name = "تأیید شده")] Confirmed = 1,
        [Display(Name = "لغو شده")] Canceled = 2,
        [Display(Name = "انجام شده")] Done = 3,
    }

    /// <summary>نوبت رزرو شده مشتری</summary>
    public class Tbl_Reservation : Tbl_BaseEntity
    {
        [Display(Name = "TC سالن")]
        public Guid SalonTC { get; set; }

        [Display(Name = "TC مشتری")]
        [Required(ErrorMessage = "TC مشتری الزامی است")]
        public Guid CustomerTC { get; set; }

        [Display(Name = "نام مشتری")]
        [Required(ErrorMessage = "نام مشتری الزامی است")]
        [MaxLength(100)]
        public string CustomerName { get; set; } = string.Empty;

        [Display(Name = "شماره موبایل")]
        [Required(ErrorMessage = "شماره موبایل الزامی است")]
        [MaxLength(15)]
        public string MobileNumber { get; set; } = string.Empty;

        [Display(Name = "TC خدمت")]
        public Guid ServiceTC { get; set; }

        [Display(Name = "نام خدمت")]
        [Required(ErrorMessage = "نام خدمت الزامی است")]
        [MaxLength(150)]
        public string ServiceName { get; set; } = string.Empty;

        [Display(Name = "TC پرسنل")]
        public Guid PersonalTC { get; set; }

        [Display(Name = "نام پرسنل")]
        [MaxLength(100)]
        public string? PersonalName { get; set; }

        [Display(Name = "TC نمونه کار مرجع")]
        public Guid? PortfolioTC { get; set; }

        [Display(Name = "تاریخ نوبت")]
        [Required(ErrorMessage = "تاریخ نوبت الزامی است")]
        public DateTime ReserveDate { get; set; }

        [Display(Name = "ساعت نوبت")]
        [Required(ErrorMessage = "ساعت نوبت الزامی است")]
        public TimeSpan ReserveTime { get; set; }

        [Display(Name = "مدت زمان (دقیقه)")]
        [Range(0, 1440, ErrorMessage = "مدت زمان معتبر نیست")]
        public int DurationMinutes { get; set; }

        [Display(Name = "قیمت ثبت شده")]
        [Range(0, double.MaxValue, ErrorMessage = "قیمت نمی‌تواند منفی باشد")]
        public decimal Price { get; set; }

        [Display(Name = "بیعانه")]
        [Range(0, double.MaxValue, ErrorMessage = "بیعانه نمی‌تواند منفی باشد")]
        public decimal Deposit { get; set; }

        [Display(Name = "یادداشت مشتری")]
        [MaxLength(500)]
        public string? CustomerNote { get; set; }

        [Display(Name = "وضعیت")]
        public ReservationStatus Status { get; set; } = ReservationStatus.Pending;

        [Display(Name = "تاریخ تأیید")]
        public DateTime? ConfirmDate { get; set; }

        [Display(Name = "دلیل لغو")]
        [MaxLength(300)]
        public string? CancelReason { get; set; }
    }
}
