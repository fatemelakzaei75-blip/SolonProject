using DataCore.Interfaces;
using DataCore.Services;
using DataLayer.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebApiSolon.Models;
using WebApiSolon.Services;

namespace WebApiSolon.Controllers;

/// <summary>احراز هویت کاربران پنل — ورود با موبایل + کد تأیید و صدور توکن JWT</summary>
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IConfirmService _confirm;
    private readonly IMobileService _mobile;
    private readonly ICustomerService _customers;
    private readonly UserRoleService _userRoles;
    private readonly DatabaseContext _db;
    private readonly JwtTokenService _jwt;
    private readonly ILogger<AuthController> _logger;

    /// <summary>کد تأیید ثابت محیط توسعه</summary>
    public const string DevCode = ConfirmService.DevCode;

    /// <summary>حساب های نمونه برای زمانی که دیتابیس در دسترس نیست</summary>
    private static readonly Dictionary<string, (string Name, string Role)> DemoUsers = new()
    {
        ["09120000001"] = ("مدیر سالن حدیث", "Admin"),
        ["09120000002"] = ("سارا محمدی (پرسنل)", "Personnel"),
        ["09120000003"] = ("نگار رضایی (مشتری)", "Customer"),
    };

    public AuthController(IConfirmService confirm, IMobileService mobile, ICustomerService customers,
        UserRoleService userRoles, DatabaseContext db, JwtTokenService jwt, ILogger<AuthController> logger)
    {
        _confirm = confirm; _mobile = mobile; _customers = customers;
        _userRoles = userRoles; _db = db; _jwt = jwt; _logger = logger;
    }

    /// <summary>ارسال کد تأیید (ثبت در Tbl_Confirm)</summary>
    [HttpPost("send-code")]
    public ActionResult<ApiResult> SendCode([FromBody] SendCodeRequest request)
    {
        request.MobileNumber = DigitHelper.Normalize(request.MobileNumber);
        if (!IsValidMobile(request.MobileNumber))
            return BadRequest(new ApiResult { Message = "شماره موبایل معتبر نیست" });

        try { _confirm.SendCode(request.MobileNumber); }
        catch (Exception ex) { _logger.LogWarning(ex, "ارسال کد بدون دیتابیس (حالت نمونه)"); }

        return Ok(new ApiResult { Success = true, Message = $"کد تأیید ارسال شد (کد محیط توسعه: {DevCode})" });
    }

    /// <summary>ورود و دریافت توکن JWT</summary>
    [HttpPost("login")]
    public ActionResult<LoginResponse> Login([FromBody] LoginRequest request)
    {
        request.MobileNumber = DigitHelper.Normalize(request.MobileNumber);
        request.Code = DigitHelper.Normalize(request.Code);

        if (!IsValidMobile(request.MobileNumber) || string.IsNullOrWhiteSpace(request.Code))
            return BadRequest(new ApiResult { Message = "اطلاعات ورود معتبر نیست" });

        var roles = new List<string>();
        var displayName = "کاربر";
        var tc = Guid.NewGuid();
        var verified = false;

        try
        {
            verified = _confirm.VerifyCode(request.MobileNumber, request.Code);
            if (verified)
            {
                var mobile = _mobile.Create(request.MobileNumber);
                tc = mobile.Tc;

                if (Guid.TryParse(mobile.TcPersonal, out var personalTc) && personalTc != Guid.Empty)
                {
                    tc = personalTc;
                    roles = _userRoles.GetRoleNamesByPersonalTc(personalTc);
                    displayName = "پرسنل سالن";
                }
                else if (_customers.IsCustomerExists(mobile.Tc))
                {
                    displayName = _customers.GetCustomerByToken(mobile.Tc).FullName;
                    roles.Add("Customer");
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "ورود بدون دیتابیس (حالت نمونه)");
        }

        // حالت نمونه / محیط توسعه
        if (!verified || roles.Count == 0)
        {
            if (request.Code != DevCode || !DemoUsers.TryGetValue(request.MobileNumber, out var demo))
                return Unauthorized(new ApiResult { Message = "شماره موبایل یا کد تأیید نادرست است" });

            displayName = demo.Name;
            roles = new List<string> { demo.Role };
        }

        var (token, expires) = _jwt.CreateToken(tc, displayName, request.MobileNumber, roles);
        return Ok(new LoginResponse
        {
            Token = token, ExpiresAt = expires, DisplayName = displayName,
            MobileNumber = request.MobileNumber, Tc = tc, Roles = roles
        });
    }

    private static bool IsValidMobile(string mobile)
        => System.Text.RegularExpressions.Regex.IsMatch(mobile, @"^09\d{9}$");

    /// <summary>اطلاعات کاربر جاری از روی توکن</summary>
    [Authorize]
    [HttpGet("me")]
    public ActionResult<LoginResponse> Me() => Ok(new LoginResponse
    {
        DisplayName = User.FindFirstValue(ClaimTypes.Name) ?? "",
        MobileNumber = User.FindFirstValue(ClaimTypes.MobilePhone) ?? "",
        Tc = Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var g) ? g : Guid.Empty,
        Roles = User.FindAll(ClaimTypes.Role).Select(c => c.Value).ToList()
    });
}
