using DataCore.Interfaces;
using DataLayer.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebApiSolon.Models;

namespace WebApiSolon.Controllers;

/// <summary>ثبت و مدیریت نوبت ها</summary>
[ApiController]
[Route("api/[controller]")]
public class ReservationController : ControllerBase
{
    private readonly IReservationService _reservations;
    public ReservationController(IReservationService reservations) => _reservations = reservations;

    private Guid CurrentTc =>
        Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var g) ? g : Guid.Empty;

    private bool IsInRole(string role) => User.IsInRole(role);

    /// <summary>فهرست نوبت ها (مدیر: همه، پرسنل: نوبت های خودش، مشتری: نوبت های خودش)</summary>
    [Authorize]
    [HttpGet]
    public ActionResult<List<Tbl_Reservation>> GetAll()
    {
        if (IsInRole("Admin")) return Ok(_reservations.GetReservations());
        if (IsInRole("Personnel")) return Ok(_reservations.GetByPersonalTC(CurrentTc));
        return Ok(_reservations.GetByCustomerTC(CurrentTc));
    }

    /// <summary>نوبت های یک روز مشخص (مدیر و پرسنل)</summary>
    [Authorize(Roles = "Admin,Personnel")]
    [HttpGet("by-date")]
    public ActionResult<List<Tbl_Reservation>> GetByDate([FromQuery] DateTime date)
        => Ok(_reservations.GetByDate(date));

    /// <summary>جزئیات یک نوبت</summary>
    [Authorize]
    [HttpGet("{tc:guid}")]
    public ActionResult<Tbl_Reservation> Get(Guid tc)
    {
        var item = _reservations.GetReservationByTC(tc);
        return item is null ? NotFound(new ApiResult { Message = "نوبت یافت نشد" }) : Ok(item);
    }

    /// <summary>ثبت نوبت جدید — مهمان هم می تواند رزرو کند</summary>
    [AllowAnonymous]
    [HttpPost]
    public ActionResult<Tbl_Reservation> Create([FromBody] Tbl_Reservation reservation)
    {
        if (string.IsNullOrWhiteSpace(reservation.CustomerName) ||
            string.IsNullOrWhiteSpace(reservation.MobileNumber) ||
            string.IsNullOrWhiteSpace(reservation.ServiceName))
            return BadRequest(new ApiResult { Message = "نام، شماره موبایل و خدمت الزامی است" });

        // اگر کاربر وارد شده باشد، نوبت به حساب او متصل می شود
        if (User.Identity?.IsAuthenticated == true && CurrentTc != Guid.Empty && IsInRole("Customer"))
            reservation.CustomerTC = CurrentTc;

        var saved = _reservations.AddReservation(reservation);
        return saved is null
            ? StatusCode(500, new ApiResult { Message = "ثبت نوبت ناموفق بود" })
            : Ok(saved);
    }

    /// <summary>تغییر وضعیت نوبت (مدیر و پرسنل)</summary>
    [Authorize(Roles = "Admin,Personnel")]
    [HttpPatch("{tc:guid}/status")]
    public ActionResult<ApiResult> ChangeStatus(Guid tc, [FromBody] ChangeStatusRequest request)
        => _reservations.ChangeStatus(tc, request.Status, request.CancelReason)
            ? Ok(new ApiResult { Success = true, Message = "وضعیت نوبت به روزرسانی شد" })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });

    /// <summary>لغو نوبت توسط مشتری</summary>
    [Authorize]
    [HttpPatch("{tc:guid}/cancel")]
    public ActionResult<ApiResult> Cancel(Guid tc, [FromBody] ChangeStatusRequest? request)
    {
        var item = _reservations.GetReservationByTC(tc);
        if (item is null) return NotFound(new ApiResult { Message = "نوبت یافت نشد" });

        if (!IsInRole("Admin") && !IsInRole("Personnel") && item.CustomerTC != CurrentTc)
            return Forbid();

        return _reservations.ChangeStatus(tc, ReservationStatus.Canceled, request?.CancelReason ?? "لغو توسط کاربر")
            ? Ok(new ApiResult { Success = true, Message = "نوبت لغو شد" })
            : StatusCode(500, new ApiResult { Message = "لغو نوبت ناموفق بود" });
    }

    /// <summary>ویرایش نوبت (مدیر)</summary>
    [Authorize(Roles = "Admin")]
    [HttpPut("{tc:guid}")]
    public ActionResult<ApiResult> Update(Guid tc, [FromBody] Tbl_Reservation reservation)
    {
        reservation.Tc = tc;
        return _reservations.EditReservation(reservation)
            ? Ok(new ApiResult { Success = true, Message = "نوبت ویرایش شد" })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });
    }

    /// <summary>حذف نوبت (مدیر)</summary>
    [Authorize(Roles = "Admin")]
    [HttpDelete("{tc:guid}")]
    public ActionResult<ApiResult> Delete(Guid tc)
        => _reservations.DeleteReservation(tc)
            ? Ok(new ApiResult { Success = true, Message = "نوبت حذف شد" })
            : NotFound(new ApiResult { Message = "نوبت یافت نشد" });
}

/// <summary>درخواست تغییر وضعیت نوبت</summary>
public class ChangeStatusRequest
{
    public ReservationStatus Status { get; set; }
    public string? CancelReason { get; set; }
}
