using DataLayer.Context;
using DataLayer.Entity;

namespace WebApiSolon.Services;

/// <summary>داده اولیه برای حالت توسعه (دیتابیس درون حافظه ای)</summary>
public static class DevDataSeeder
{
    public static readonly Guid SalonTc = Guid.Parse("11111111-1111-1111-1111-111111111111");

    public static void Seed(DatabaseContext db)
    {
        if (db.Tbl_Salon.Any()) return;
        var now = DateTime.Now;

        db.Tbl_Salon.Add(new Tbl_Salon
        {
            Tc = SalonTc, IsActive = true, RegisterData = now,
            Phone1 = "02112345678", Phone2 = "09120000001", Logo1 = "img/hero.jpg",
            TextSalon = "سالن زیبایی حدیث؛ تجربه ای آرام، لوکس و حرفه ای از خدمات زیبایی."
        });

        var cats = new[] { "مو", "پوست", "ناخن", "میکاپ و عروس", "مژه و ابرو" }
            .Select(n => new Tbl_Category { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc, CategoryName = n })
            .ToList();
        db.Tbl_Category.AddRange(cats);

        var services = new (string Name, int Cat, decimal Price, bool Main)[]
        {
            ("رنگ و لایت", 0, 2_500_000, true), ("کراتین و احیا", 0, 3_800_000, true),
            ("کوپ و براشینگ", 0, 900_000, false), ("فیشال پوست", 1, 1_400_000, true),
            ("کاشت ناخن", 2, 1_900_000, true), ("مانیکور و پدیکور", 2, 700_000, false),
            ("میکاپ عروس", 3, 7_500_000, true), ("شنیون", 3, 2_200_000, false),
            ("اکستنشن مژه", 4, 1_200_000, true), ("لیفت و لمینت مژه", 4, 950_000, false),
        };
        db.Tbl_SalonSerice.AddRange(services.Select(s => new Tbl_SalonSerice
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc,
            CategoryTC = cats[s.Cat].Tc, ServiceName = s.Name, Price = s.Price, Main = s.Main,
            Description = $"خدمت {s.Name} در سالن زیبایی حدیث"
        }));

        var roles = new[]
        {
            new Tbl_Roles { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, RoleName = "Admin", Description = "مدیر سیستم" },
            new Tbl_Roles { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, RoleName = "Personnel", Description = "پرسنل سالن" },
            new Tbl_Roles { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, RoleName = "Customer", Description = "مشتری" },
        };
        db.Tbl_Roles.AddRange(roles);

        db.Tbl_Permission.AddRange(new[] { "مدیریت اطلاعات پایه", "مدیریت پرسنل", "مدیریت مشتریان", "مدیریت نمونه کار", "مشاهده گزارش ها" }
            .Select(p => new Tbl_Permission { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, PermissionName = p }));

        // پرسنل نمونه + موبایل + نقش
        var personal = new Tbl_Personal
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
            salon_Tc = SalonTc, TC_Service = Guid.NewGuid(), BirthDate = new DateTime(1995, 5, 12)
        };
        db.Tbl_Personal.Add(personal);
        db.Tbl_Mobile.Add(new Tbl_Mobile { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, MobileNumber = "09120000002", TcPersonal = personal.Tc.ToString() });
        db.Tbl_UserRole.Add(new Tbl_UserRole { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, PersonalTC = personal.Tc, RoleTC = roles[1].Tc });

        // مشتری نمونه
        var customerMobileTc = Guid.NewGuid();
        db.Tbl_Mobile.Add(new Tbl_Mobile { Tc = customerMobileTc, IsActive = true, RegisterData = now, MobileNumber = "09120000003", TcPersonal = string.Empty });
        db.Tbl_Customer.Add(new Tbl_Customer { Tc = customerMobileTc, IsActive = true, RegisterData = now, FullName = "نگار رضایی", CodeMoaref = "HB2451" });
        db.Tbl_Customer.AddRange(new[] { "مریم احمدی", "سحر کریمی", "الهام نوری" }
            .Select(n => new Tbl_Customer { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, FullName = n, CodeMoaref = "HB" + Random.Shared.Next(1000, 9999) }));

        var portfolioCats = new[] { "نمونه کار ناخن", "نمونه کار مو", "نمونه کار میکاپ" }
            .Select((n, i) => new Tbl_CategoryPortfolio
            {
                Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc,
                CategoryNameSample = n, SamplePic = $"img/gallery-{i + 1}.jpg"
            }).ToList();
        db.Tbl_CategoryPortfolio.AddRange(portfolioCats);

        db.Tbl_Portfoilo.AddRange(Enumerable.Range(0, 6).Select(i => new Tbl_Portfoilo
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
            SampleTC = portfolioCats[i % portfolioCats.Count].Tc,
            Title = $"نمونه کار شماره {i + 1}", Description = "کار انجام شده در سالن زیبایی حدیث",
            ProtfiloPic = $"img/gallery-{(i % 3) + 1}.jpg"
        }));

        db.Tbl_Social.Add(new Tbl_Social { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, TC_Salon = SalonTc, SocialLink = "https://instagram.com/hadisbeauty.salon", Pics = "instagram" });

        db.Tbl_NewsDay.Add(new Tbl_NewsDay
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
            TextNews = "تخفیف ۲۰٪ خدمات ناخن در روزهای ابتدای هفته",
            DateStart = now.Date, DateEnd = now.Date.AddDays(14),
            TimeStart = new TimeSpan(10, 0, 0), TimeEnd = new TimeSpan(20, 0, 0),
            TC_Personal = personal.Tc
        });

        db.SaveChanges();
    }
}
