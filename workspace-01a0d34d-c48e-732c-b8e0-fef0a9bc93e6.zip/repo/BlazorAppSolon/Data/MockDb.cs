using DataLayer.Entity;
using DataLayer.Entity.BaseEntity;

namespace BlazorAppSolon.Data;

/// <summary>
/// منبع داده محلی (نمونه) برای پنل ها تا بدون SQL Server هم کاملاً قابل استفاده باشند.
/// ساختار متدها عمداً شبیه WebApi است تا جایگزینی با HttpClient ساده باشد.
/// </summary>
public class MockDb
{
    private readonly Dictionary<Type, List<Tbl_BaseEntity>> _store = new();

    public static readonly Guid SalonTc = Guid.Parse("11111111-1111-1111-1111-111111111111");

    public MockDb() => Seed();

    private List<Tbl_BaseEntity> Bucket(Type t)
    {
        if (!_store.TryGetValue(t, out var list)) _store[t] = list = new List<Tbl_BaseEntity>();
        return list;
    }

    public List<T> All<T>() where T : Tbl_BaseEntity
        => Bucket(typeof(T)).Where(x => !x.IsDelete).Cast<T>().ToList();

    public T? Find<T>(Guid tc) where T : Tbl_BaseEntity
        => All<T>().FirstOrDefault(x => x.Tc == tc);

    public void Add<T>(T entity) where T : Tbl_BaseEntity
    {
        var list = Bucket(typeof(T));
        entity.ID = list.Count == 0 ? 1 : list.Max(x => x.ID) + 1;
        if (entity.Tc == Guid.Empty) entity.Tc = Guid.NewGuid();
        if (entity.RegisterData == default) entity.RegisterData = DateTime.Now;
        list.Add(entity);
    }

    public void Update<T>(T entity) where T : Tbl_BaseEntity
    {
        var list = Bucket(typeof(T));
        var idx = list.FindIndex(x => x.Tc == entity.Tc);
        if (idx >= 0) list[idx] = entity;
    }

    /// <summary>حذف منطقی</summary>
    public void Delete<T>(Guid tc) where T : Tbl_BaseEntity
    {
        var item = Bucket(typeof(T)).FirstOrDefault(x => x.Tc == tc);
        if (item is not null) { item.IsDelete = true; item.IsActive = false; }
    }

    public int Count<T>() where T : Tbl_BaseEntity => All<T>().Count;

    // --------------------------------------------------------------
    private void Seed()
    {
        var now = DateTime.Now;

        Add(new Tbl_Salon
        {
            Tc = SalonTc, IsActive = true, RegisterData = now,
            Phone1 = "02112345678", Phone2 = "09120000001",
            Logo1 = "img/hero.jpg",
            TextSalon = "سالن زیبایی حدیث؛ تجربه ای آرام، لوکس و حرفه ای از خدمات زیبایی."
        });

        var catNames = new[] { "مو", "پوست", "ناخن", "میکاپ و عروس", "مژه و ابرو" };
        var cats = new List<Tbl_Category>();
        foreach (var name in catNames)
        {
            var c = new Tbl_Category { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc, CategoryName = name };
            cats.Add(c); Add(c);
        }

        var services = new (string Name, int Cat, decimal Price, bool Main)[]
        {
            ("رنگ و لایت", 0, 2_500_000, true),
            ("کراتین و احیا", 0, 3_800_000, true),
            ("کوپ و براشینگ", 0, 900_000, false),
            ("اکستنشن مو", 0, 6_500_000, false),
            ("فیشال پوست", 1, 1_400_000, true),
            ("ماساژ صورت", 1, 800_000, false),
            ("کاشت ناخن", 2, 1_900_000, true),
            ("مانیکور و پدیکور", 2, 700_000, false),
            ("میکاپ عروس", 3, 7_500_000, true),
            ("شنیون", 3, 2_200_000, false),
            ("اکستنشن مژه", 4, 1_200_000, true),
            ("لیفت و لمینت مژه", 4, 950_000, false),
        };
        foreach (var s in services)
            Add(new Tbl_SalonSerice
            {
                Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
                SalonTC = SalonTc, CategoryTC = cats[s.Cat].Tc,
                ServiceName = s.Name, Price = s.Price, Main = s.Main,
                Description = $"خدمت {s.Name} در سالن زیبایی حدیث"
            });

        foreach (var role in new[] { ("Admin", "مدیر سیستم"), ("Personnel", "پرسنل سالن"), ("Customer", "مشتری") })
            Add(new Tbl_Roles { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, RoleName = role.Item1, Description = role.Item2 });

        foreach (var p in new[] { "مدیریت اطلاعات پایه", "مدیریت پرسنل", "مدیریت مشتریان", "مدیریت نمونه کار", "مشاهده گزارش ها" })
            Add(new Tbl_Permission { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, PermissionName = p });

        var roles = All<Tbl_Roles>();
        foreach (var perm in All<Tbl_Permission>())
            Add(new Tbl_RolePermission { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, PermissionTC = perm.Tc });

        var personals = new (string Mobile, string Service)[]
        {
            ("09121110001", "رنگ و لایت"), ("09121110002", "کاشت ناخن"), ("09121110003", "میکاپ عروس")
        };
        var allServices = All<Tbl_SalonSerice>();
        foreach (var (mobile, svcName) in personals)
        {
            var svc = allServices.First(s => s.ServiceName == svcName);
            var personal = new Tbl_Personal
            {
                Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
                salon_Tc = SalonTc, TC_Service = svc.Tc, BirthDate = new DateTime(1995, 5, 12)
            };
            Add(personal);
            Add(new Tbl_Mobile { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, MobileNumber = mobile, TcPersonal = personal.Tc.ToString() });
            Add(new Tbl_UserRole { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, PersonalTC = personal.Tc, RoleTC = roles.First(r => r.RoleName == "Personnel").Tc });
        }

        foreach (var c in new[] { "نگار رضایی", "مریم احمدی", "سحر کریمی", "الهام نوری" })
            Add(new Tbl_Customer { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, FullName = c, CodeMoaref = "HB" + Random.Shared.Next(1000, 9999) });

        var portfolioCats = new[] { "نمونه کار ناخن", "نمونه کار مو", "نمونه کار میکاپ" };
        var pcs = new List<Tbl_CategoryPortfolio>();
        for (int i = 0; i < portfolioCats.Length; i++)
        {
            var pc = new Tbl_CategoryPortfolio
            {
                Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc,
                CategoryNameSample = portfolioCats[i], SamplePic = $"img/gallery-{i + 1}.jpg"
            };
            pcs.Add(pc); Add(pc);
        }

        for (int i = 0; i < 6; i++)
            Add(new Tbl_Portfoilo
            {
                Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
                SampleTC = pcs[i % pcs.Count].Tc,
                Title = $"نمونه کار شماره {i + 1}",
                Description = "کار انجام شده در سالن زیبایی حدیث",
                ProtfiloPic = $"img/gallery-{(i % 3) + 1}.jpg"
            });

        Add(new Tbl_Social { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, TC_Salon = SalonTc, SocialLink = "https://instagram.com/hadisbeauty.salon", Pics = "instagram" });
        Add(new Tbl_Social { Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, TC_Salon = SalonTc, SocialLink = "https://t.me/hadisbeauty", Pics = "telegram" });

        var firstPersonal = All<Tbl_Personal>().First();

        var firstCustomer = All<Tbl_Customer>().First();
        var nailService = allServices.First(s => s.ServiceName == "کاشت ناخن");
        Add(new Tbl_Reservation
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc,
            CustomerTC = firstCustomer.Tc, CustomerName = firstCustomer.FullName, MobileNumber = "09120000003",
            ServiceTC = nailService.Tc, ServiceName = nailService.ServiceName,
            PersonalTC = firstPersonal.Tc, PersonalName = "سارا محمدی",
            ReserveDate = now.Date.AddDays(2), ReserveTime = new TimeSpan(11, 0, 0),
            DurationMinutes = 150, Price = nailService.Price, Deposit = 400_000,
            Status = ReservationStatus.Confirmed, ConfirmDate = now
        });
        Add(new Tbl_Reservation
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now, SalonTC = SalonTc,
            CustomerTC = firstCustomer.Tc, CustomerName = firstCustomer.FullName, MobileNumber = "09120000003",
            ServiceTC = allServices.First(s => s.ServiceName == "فیشال پوست").Tc, ServiceName = "فیشال پوست",
            PersonalTC = firstPersonal.Tc, PersonalName = "الهام نوری",
            ReserveDate = now.Date.AddDays(9), ReserveTime = new TimeSpan(17, 30, 0),
            DurationMinutes = 75, Price = 1_400_000, Deposit = 280_000,
            CustomerNote = "پوست حساس", Status = ReservationStatus.Pending
        });
        Add(new Tbl_NewsDay
        {
            Tc = Guid.NewGuid(), IsActive = true, RegisterData = now,
            TextNews = "تخفیف ۲۰٪ خدمات ناخن در روزهای ابتدای هفته",
            DateStart = now.Date, DateEnd = now.Date.AddDays(14),
            TimeStart = new TimeSpan(10, 0, 0), TimeEnd = new TimeSpan(20, 0, 0),
            TC_Personal = firstPersonal.Tc
        });
    }
}
