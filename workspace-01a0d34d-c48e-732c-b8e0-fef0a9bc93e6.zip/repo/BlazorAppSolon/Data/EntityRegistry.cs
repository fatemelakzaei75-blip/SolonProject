using DataLayer.Entity;

namespace BlazorAppSolon.Data;

/// <summary>توصیف یک موجودیت اطلاعات پایه برای منوی پنل ادمین و مسیر API آن</summary>
public record EntityDescriptor(string Key, string Title, string Group, Type EntityType, string Icon, string ApiRoute);

/// <summary>فهرست تمام موجودیت های اطلاعات پایه (۱۶ جدول)</summary>
public static class EntityRegistry
{
    public static readonly EntityDescriptor[] All =
    {
        new("salon",             "مشخصات سالن",       "سالن",      typeof(Tbl_Salon),             "🏠", "Salon"),
        new("category",          "دسته بندی خدمات",   "سالن",      typeof(Tbl_Category),          "🗂", "Category"),
        new("salon-service",     "خدمات سالن",        "سالن",      typeof(Tbl_SalonSerice),       "💅", "SalonService"),
        new("social",            "شبکه های اجتماعی",  "سالن",      typeof(Tbl_Social),            "🔗", "Social"),
        new("news-day",          "خبر روز / تخفیف",    "سالن",      typeof(Tbl_NewsDay),           "📣", "NewsDay"),
        new("reservation",       "نوبت ها",           "سالن",      typeof(Tbl_Reservation),       "🗓", "Reservation"),

        new("personal",          "پرسنل",             "کاربران",   typeof(Tbl_Personal),          "👩‍🎨", "Personal"),
        new("customer",          "مشتریان",           "کاربران",   typeof(Tbl_Customer),          "👥", "Customer"),
        new("mobile",            "شماره های موبایل",  "کاربران",   typeof(Tbl_Mobile),            "📱", "Mobile"),
        new("confirm",           "کدهای تأیید",       "کاربران",   typeof(Tbl_Confirm),           "🔐", "Confirm"),

        new("role",              "نقش ها",            "دسترسی",    typeof(Tbl_Roles),             "🎫", "Role"),
        new("permission",        "دسترسی ها",         "دسترسی",    typeof(Tbl_Permission),        "🔑", "Permission"),
        new("role-permission",   "نقش-دسترسی",        "دسترسی",    typeof(Tbl_RolePermission),    "🧩", "RolePermission"),
        new("user-role",         "نقش کاربران",       "دسترسی",    typeof(Tbl_UserRole),          "🧑‍💼", "UserRole"),

        new("category-portfolio","دسته نمونه کار",    "نمونه کار", typeof(Tbl_CategoryPortfolio), "📁", "CategoryPortfolio"),
        new("portfolio",         "نمونه کارها",       "نمونه کار", typeof(Tbl_Portfoilo),         "🖼", "Portfolio"),
        new("like",              "لایک ها",           "نمونه کار", typeof(Tbl_Like),              "❤️", "Like"),
    };

    public static EntityDescriptor? ByKey(string key)
        => All.FirstOrDefault(e => e.Key.Equals(key, StringComparison.OrdinalIgnoreCase));

    /// <summary>مسیر کنترلر API متناظر با نوع موجودیت</summary>
    public static string ApiRouteFor(Type entityType)
        => All.FirstOrDefault(e => e.EntityType == entityType)?.ApiRoute ?? entityType.Name;

    public static IEnumerable<IGrouping<string, EntityDescriptor>> Grouped() => All.GroupBy(e => e.Group);
}
