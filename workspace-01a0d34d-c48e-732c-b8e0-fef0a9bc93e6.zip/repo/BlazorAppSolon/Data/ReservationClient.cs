using System.Net.Http.Json;
using System.Security.Claims;
using BlazorAppSolon.Auth;
using DataLayer.Entity;
using Microsoft.AspNetCore.Components.Authorization;

namespace BlazorAppSolon.Data;

/// <summary>
/// ثبت و مدیریت نوبت ها از طریق WebApi (جدول Tbl_Reservation).
/// در نبود سرویس، روی داده نمونه محلی کار می کند تا جریان کاربر قطع نشود.
/// </summary>
public class ReservationClient
{
    private readonly HttpClient _http;
    private readonly MockDb _mock;
    private readonly JwtAuthenticationStateProvider _auth;
    private readonly AuthenticationStateProvider _state;

    public bool IsOnline { get; private set; } = true;

    public ReservationClient(HttpClient http, MockDb mock, JwtAuthenticationStateProvider auth, AuthenticationStateProvider state)
    {
        _http = http; _mock = mock; _auth = auth; _state = state;
    }

    private async Task AttachTokenAsync()
    {
        var token = await _auth.GetTokenAsync();
        if (!string.IsNullOrWhiteSpace(token))
            _http.DefaultRequestHeaders.Authorization = new("Bearer", token);
    }

    private async Task<(Guid Tc, string Name, string Mobile, string Role)> CurrentUserAsync()
    {
        var s = await _state.GetAuthenticationStateAsync();
        var u = s.User;
        if (u.Identity?.IsAuthenticated != true) return (Guid.Empty, "", "", "");

        Guid.TryParse(u.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var tc);
        return (tc,
                u.Identity.Name ?? "",
                u.FindFirst(ClaimTypes.MobilePhone)?.Value ?? "",
                u.FindFirst(ClaimTypes.Role)?.Value ?? "");
    }

    /// <summary>نوبت های کاربر جاری (مشتری: نوبت های خودش، پرسنل/مدیر: مرتبط)</summary>
    public async Task<List<Tbl_Reservation>> MineAsync()
    {
        try
        {
            await AttachTokenAsync();
            var list = await _http.GetFromJsonAsync<List<Tbl_Reservation>>($"{AuthService.ApiBase}/api/reservation");
            if (list is not null) { IsOnline = true; return list; }
        }
        catch { IsOnline = false; }

        var (tc, _, _, role) = await CurrentUserAsync();
        var local = _mock.All<Tbl_Reservation>();
        return role switch
        {
            "Admin" => local,
            "Personnel" => local.Where(r => r.PersonalTC == tc || r.PersonalTC == Guid.Empty).ToList(),
            _ => local.Where(r => r.CustomerTC == tc || r.CustomerTC == Guid.Empty).ToList()
        };
    }

    /// <summary>ثبت نوبت جدید (مهمان هم مجاز است)</summary>
    public async Task<(bool Ok, string Message, Tbl_Reservation? Item)> CreateAsync(Tbl_Reservation reservation)
    {
        var (tc, name, mobile, role) = await CurrentUserAsync();
        if (role == "Customer" && tc != Guid.Empty)
        {
            reservation.CustomerTC = tc;
            if (string.IsNullOrWhiteSpace(reservation.CustomerName)) reservation.CustomerName = name;
            if (string.IsNullOrWhiteSpace(reservation.MobileNumber)) reservation.MobileNumber = mobile;
        }

        reservation.MobileNumber = DigitHelper.Normalize(reservation.MobileNumber);
        reservation.Status = ReservationStatus.Pending;
        reservation.IsActive = true;
        reservation.RegisterData = DateTime.Now;
        if (reservation.Tc == Guid.Empty) reservation.Tc = Guid.NewGuid();

        try
        {
            await AttachTokenAsync();
            var res = await _http.PostAsJsonAsync($"{AuthService.ApiBase}/api/reservation", reservation);
            if (res.IsSuccessStatusCode)
            {
                IsOnline = true;
                var saved = await res.Content.ReadFromJsonAsync<Tbl_Reservation>();
                return (true, "درخواست نوبت شما ثبت شد و پس از تأیید سالن نهایی می شود.", saved ?? reservation);
            }
        }
        catch { IsOnline = false; }

        _mock.Add(reservation);
        return (true, "درخواست نوبت ثبت شد (حالت آفلاین).", reservation);
    }

    /// <summary>تغییر وضعیت نوبت (پرسنل/مدیر)</summary>
    public async Task<bool> ChangeStatusAsync(Guid tc, ReservationStatus status, string? cancelReason = null)
    {
        try
        {
            await AttachTokenAsync();
            var res = await _http.PatchAsJsonAsync($"{AuthService.ApiBase}/api/reservation/{tc}/status",
                new { Status = status, CancelReason = cancelReason });
            if (res.IsSuccessStatusCode) { IsOnline = true; return true; }
        }
        catch { IsOnline = false; }

        var item = _mock.Find<Tbl_Reservation>(tc);
        if (item is null) return false;
        item.Status = status;
        if (status == ReservationStatus.Confirmed) item.ConfirmDate = DateTime.Now;
        if (status == ReservationStatus.Canceled) item.CancelReason = cancelReason;
        return true;
    }

    /// <summary>لغو نوبت توسط مشتری</summary>
    public async Task<bool> CancelAsync(Guid tc, string? reason = null)
    {
        try
        {
            await AttachTokenAsync();
            var res = await _http.PatchAsJsonAsync($"{AuthService.ApiBase}/api/reservation/{tc}/cancel",
                new { Status = ReservationStatus.Canceled, CancelReason = reason ?? "لغو توسط مشتری" });
            if (res.IsSuccessStatusCode) { IsOnline = true; return true; }
        }
        catch { IsOnline = false; }

        return await ChangeStatusAsync(tc, ReservationStatus.Canceled, reason);
    }

    /// <summary>برچسب فارسی وضعیت</summary>
    public static string StatusLabel(ReservationStatus s) => s switch
    {
        ReservationStatus.Pending => "در انتظار تأیید",
        ReservationStatus.Confirmed => "تأیید شده",
        ReservationStatus.Canceled => "لغو شده",
        ReservationStatus.Done => "انجام شده",
        _ => "-"
    };

    public static string StatusCss(ReservationStatus s) => s switch
    {
        ReservationStatus.Confirmed or ReservationStatus.Done => "ok",
        ReservationStatus.Canceled => "off",
        _ => "wait"
    };
}
