using DataLayer.Entity;

namespace DataCore.Interfaces
{
    /// <summary>مدیریت نوبت های سالن</summary>
    public interface IReservationService
    {
        List<Tbl_Reservation> GetReservations();
        Tbl_Reservation? GetReservationByTC(Guid tc);
        List<Tbl_Reservation> GetByCustomerTC(Guid customerTC);
        List<Tbl_Reservation> GetByPersonalTC(Guid personalTC);
        List<Tbl_Reservation> GetByDate(DateTime date);

        /// <summary>ثبت نوبت؛ اگر مشتری وجود نداشته باشد ساخته می شود</summary>
        Tbl_Reservation? AddReservation(Tbl_Reservation reservation);

        bool EditReservation(Tbl_Reservation reservation);
        bool ChangeStatus(Guid tc, ReservationStatus status, string? cancelReason = null);
        bool DeleteReservation(Guid tc);
    }
}
