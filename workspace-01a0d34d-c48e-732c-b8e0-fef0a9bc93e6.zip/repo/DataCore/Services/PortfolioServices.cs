using DataCore.Interfaces;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.EntityFrameworkCore;

namespace DataCore.Services;

/// <summary>دسته بندی نمونه کارها</summary>
public class CategoryPortfolioService : BaseRepository<Tbl_CategoryPortfolio>, ICategoryPortfolioService
{
    public CategoryPortfolioService(DatabaseContext db) : base(db) { }

    public List<Tbl_CategoryPortfolio> GetCategoryPortfolios() => GetAll();
    public Tbl_CategoryPortfolio GetCategoryPortfolioByTC(string tc) => GetByTc(tc)!;
    public List<Tbl_CategoryPortfolio> GetCategoryPortfoliosBySalonTC(string salonTC)
        => Guid.TryParse(salonTC, out var g) ? Query.AsNoTracking().Where(x => x.SalonTC == g).ToList() : new();
    public List<Tbl_CategoryPortfolio> GetCategoryPortfoliosByCategoryTC(string categoryTC)
        => Guid.TryParse(categoryTC, out var g) ? Query.AsNoTracking().Where(x => x.Tc == g).ToList() : new();
    public bool AddCategoryPortfolio(Tbl_CategoryPortfolio categoryPortfolio) => Insert(categoryPortfolio);
    public bool EditCategoryPortfolio(Tbl_CategoryPortfolio categoryPortfolio) => Modify(categoryPortfolio);
    public bool DeleteCategoryPortfolio(string tc) => SoftDelete(tc);
}

/// <summary>نمونه کارها</summary>
public class PortfolioService : BaseRepository<Tbl_Portfoilo>, IPortfolioService
{
    public PortfolioService(DatabaseContext db) : base(db) { }

    public List<Tbl_Portfoilo> GetPortfolios() => GetAll();
    public Tbl_Portfoilo GetPortfolioByTC(string tc) => GetByTc(tc)!;
    public Tbl_Portfoilo GetPortfolioByPortfolioSampleTC(string portfolioSampleTC)
        => Guid.TryParse(portfolioSampleTC, out var g)
            ? Query.AsNoTracking().FirstOrDefault(x => x.SampleTC == g)!
            : null!;
    public List<Tbl_Portfoilo> SearchPortfolios(string search)
        => Query.AsNoTracking().Where(x => x.Title.Contains(search) || (x.Description ?? "").Contains(search)).ToList();

    /// <summary>پرلایک ترین نمونه کارها بر اساس Tbl_Like</summary>
    public List<Tbl_Portfoilo> GetMostLikedPortfolios()
        => (from p in Query.AsNoTracking()
            let likes = Db.Tbl_Like.Count(l => l.ProfileTC == p.Tc && !l.IsDelete)
            orderby likes descending
            select p).Take(12).ToList();

    public bool AddPortfolio(Tbl_Portfoilo portfolio) => Insert(portfolio);
    public bool EditPortfolio(Tbl_Portfoilo portfolio) => Modify(portfolio);
    public bool DeletePortfolio(string tc) => SoftDelete(tc);
}

/// <summary>لایک نمونه کارها</summary>
public class LikeService : BaseRepository<Tbl_Like>, ILikeService
{
    public LikeService(DatabaseContext db) : base(db) { }

    public bool IsLiked(string customerTC, string portfolioTC)
        => Guid.TryParse(customerTC, out var c) && Guid.TryParse(portfolioTC, out var p)
           && Query.Any(x => x.CustomerTC == c && x.ProfileTC == p);

    public bool AddLike(string customerTC, string portfolioTC)
    {
        if (!Guid.TryParse(customerTC, out var c) || !Guid.TryParse(portfolioTC, out var p)) return false;
        if (IsLiked(customerTC, portfolioTC)) return true;

        return Insert(new Tbl_Like
        {
            Tc = Guid.NewGuid(), CustomerTC = c, ProfileTC = p,
            IsActive = true, RegisterData = DateTime.Now
        });
    }

    public bool RemoveLike(string customerTC, string portfolioTC)
    {
        if (!Guid.TryParse(customerTC, out var c) || !Guid.TryParse(portfolioTC, out var p)) return false;
        var like = Set.FirstOrDefault(x => x.CustomerTC == c && x.ProfileTC == p && !x.IsDelete);
        return like is not null && SoftDelete(like.Tc);
    }

    public int GetLikeCount(string portfolioTC)
        => Guid.TryParse(portfolioTC, out var p) ? Query.Count(x => x.ProfileTC == p) : 0;

    public List<Tbl_Like> GetLikesByCustomerTC(string customerTC)
        => Guid.TryParse(customerTC, out var c) ? Query.AsNoTracking().Where(x => x.CustomerTC == c).ToList() : new();

    public List<Tbl_Like> GetLikesByPortfolioTC(string portfolioTC)
        => Guid.TryParse(portfolioTC, out var p) ? Query.AsNoTracking().Where(x => x.ProfileTC == p).ToList() : new();
}

/// <summary>
/// شمارش بازدید نمونه کارها.
/// چون جدول اختصاصی بازدید در DataLayer تعریف نشده، فعلاً در حافظه نگهداری می شود.
/// </summary>
public class PortfolioViewService : IPortfolioViewService
{
    private static readonly Dictionary<string, HashSet<string>> Views = new();

    public bool HasUserViewed(string portfolioTC, string userTC)
        => Views.TryGetValue(portfolioTC, out var users) && users.Contains(userTC);

    public bool AddView(string portfolioTC, string userTC)
    {
        if (!Views.TryGetValue(portfolioTC, out var users))
            Views[portfolioTC] = users = new HashSet<string>();
        return users.Add(userTC);
    }

    public int GetViewCount(string portfolioTC)
        => Views.TryGetValue(portfolioTC, out var users) ? users.Count : 0;
}
