using DataLayer.Context;
using DataLayer.Entity.BaseEntity;
using Microsoft.EntityFrameworkCore;

namespace DataCore.Services;

/// <summary>
/// ریپازیتوری پایه برای موجودیت های مشتق از Tbl_BaseEntity.
/// حذف همیشه به صورت منطقی (IsDelete) انجام می شود.
/// </summary>
public abstract class BaseRepository<TEntity> where TEntity : Tbl_BaseEntity
{
    protected readonly DatabaseContext Db;
    protected BaseRepository(DatabaseContext db) => Db = db;

    protected DbSet<TEntity> Set => Db.Set<TEntity>();

    protected IQueryable<TEntity> Query => Set.Where(x => !x.IsDelete);

    protected List<TEntity> GetAll() => Query.AsNoTracking().ToList();

    protected TEntity? GetByTc(Guid tc) => Query.AsNoTracking().FirstOrDefault(x => x.Tc == tc);

    protected TEntity? GetByTc(string tc) => Guid.TryParse(tc, out var g) ? GetByTc(g) : null;

    protected bool Insert(TEntity entity)
    {
        try
        {
            if (entity.Tc == Guid.Empty) entity.Tc = Guid.NewGuid();
            if (entity.RegisterData == default) entity.RegisterData = DateTime.Now;
            entity.IsDelete = false;
            Set.Add(entity);
            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }

    protected bool Modify(TEntity entity)
    {
        try
        {
            var current = Set.FirstOrDefault(x => x.Tc == entity.Tc && !x.IsDelete);
            if (current is null) return false;

            entity.ID = current.ID;
            entity.RegisterData = current.RegisterData;
            Db.Entry(current).CurrentValues.SetValues(entity);
            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }

    protected bool SoftDelete(string tc)
    {
        if (!Guid.TryParse(tc, out var g)) return false;
        return SoftDelete(g);
    }

    protected bool SoftDelete(Guid tc)
    {
        try
        {
            var current = Set.FirstOrDefault(x => x.Tc == tc && !x.IsDelete);
            if (current is null) return false;
            current.IsDelete = true;
            current.IsActive = false;
            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }
}
