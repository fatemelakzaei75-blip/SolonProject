using DataCore.Interfaces;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.EntityFrameworkCore;

namespace DataCore.Services;

/// <summary>ثبت و مدیریت نوبت ها روی جدول Tbl_Reservation</summary>
public class ReservationService : BaseRepository<Tbl_Reservation>, IReservationService
{
    public ReservationService(DatabaseContext db) : base(db) { }

    public List<Tbl_Reservation> GetReservations()
        => Query.AsNoTracking().OrderByDescending(r => r.ReserveDate).ThenBy(r => r.ReserveTime).ToList();

    public Tbl_Reservation? GetReservationByTC(Guid tc) => GetByTc(tc);

    public List<Tbl_Reservation> GetByCustomerTC(Guid customerTC)
        => Query.AsNoTracking().Where(r => r.CustomerTC == customerTC)
                .OrderByDescending(r => r.ReserveDate).ThenBy(r => r.ReserveTime).ToList();

    public List<Tbl_Reservation> GetByPersonalTC(Guid personalTC)
        => Query.AsNoTracking().Where(r => r.PersonalTC == personalTC)
                .OrderBy(r => r.ReserveDate).ThenBy(r => r.ReserveTime).ToList();

    public List<Tbl_Reservation> GetByDate(DateTime date)
        => Query.AsNoTracking().Where(r => r.ReserveDate.Date == date.Date)
                .OrderBy(r => r.ReserveTime).ToList();

    /// <summary>
    /// ثبت نوبت. رزرو توسط مهمان هم مجاز است؛ در این حالت اگر مشتری با این شماره
    /// وجود نداشته باشد، رکورد مشتری و موبایل به صورت خودکار ساخته می شود.
    /// </summary>
    public Tbl_Reservation? AddReservation(Tbl_Reservation reservation)
    {
        try
        {
            reservation.MobileNumber = NormalizeDigits(reservation.MobileNumber);

            if (reservation.CustomerTC == Guid.Empty)
                reservation.CustomerTC = EnsureCustomer(reservation.CustomerName, reservation.MobileNumber);

            reservation.Tc = reservation.Tc == Guid.Empty ? Guid.NewGuid() : reservation.Tc;
            reservation.Status = ReservationStatus.Pending;
            reservation.IsActive = true;
            reservation.RegisterData = DateTime.Now;

            return Insert(reservation) ? reservation : null;
        }
        catch { return null; }
    }

    public bool EditReservation(Tbl_Reservation reservation) => Modify(reservation);

    public bool ChangeStatus(Guid tc, ReservationStatus status, string? cancelReason = null)
    {
        try
        {
            var current = Set.FirstOrDefault(r => r.Tc == tc && !r.IsDelete);
            if (current is null) return false;

            current.Status = status;
            if (status == ReservationStatus.Confirmed) current.ConfirmDate = DateTime.Now;
            if (status == ReservationStatus.Canceled) current.CancelReason = cancelReason;

            return Db.SaveChanges() > 0;
        }
        catch { return false; }
    }

    public bool DeleteReservation(Guid tc) => SoftDelete(tc);

    /// <summary>مشتری را پیدا یا ایجاد می کند و TC آن را برمی گرداند</summary>
    private Guid EnsureCustomer(string fullName, string mobileNumber)
    {
        var mobile = Db.Tbl_Mobile.FirstOrDefault(m => m.MobileNumber == mobileNumber && !m.IsDelete);
        if (mobile is null)
        {
            mobile = new Tbl_Mobile
            {
                Tc = Guid.NewGuid(), MobileNumber = mobileNumber, TcPersonal = string.Empty,
                IsActive = true, RegisterData = DateTime.Now
            };
            Db.Tbl_Mobile.Add(mobile);
            Db.SaveChanges();
        }

        var customer = Db.Tbl_Customer.FirstOrDefault(c => c.Tc == mobile.Tc && !c.IsDelete);
        if (customer is null)
        {
            customer = new Tbl_Customer
            {
                Tc = mobile.Tc,
                FullName = string.IsNullOrWhiteSpace(fullName) ? "مشتری مهمان" : fullName,
                IsActive = true, RegisterData = DateTime.Now
            };
            Db.Tbl_Customer.Add(customer);
            Db.SaveChanges();
        }

        return customer.Tc;
    }

    private static string NormalizeDigits(string? input)
    {
        if (string.IsNullOrWhiteSpace(input)) return string.Empty;
        const string fa = "۰۱۲۳۴۵۶۷۸۹", ar = "٠١٢٣٤٥٦٧٨٩";
        var sb = new System.Text.StringBuilder();
        foreach (var ch in input.Trim())
        {
            var i = fa.IndexOf(ch); var j = ar.IndexOf(ch);
            if (i >= 0) sb.Append((char)('0' + i));
            else if (j >= 0) sb.Append((char)('0' + j));
            else if (char.IsWhiteSpace(ch) || ch is '-' or '_') continue;
            else sb.Append(ch);
        }
        return sb.ToString();
    }
}
