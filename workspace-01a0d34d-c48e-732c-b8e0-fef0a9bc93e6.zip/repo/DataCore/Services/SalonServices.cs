using DataCore.Interfaces;
using DataLayer.Context;
using DataLayer.Entity;
using Microsoft.EntityFrameworkCore;

namespace DataCore.Services;

/// <summary>مشخصات سالن</summary>
public class SalonService : BaseRepository<Tbl_Salon>, ISalonService
{
    public SalonService(DatabaseContext db) : base(db) { }

    public Tbl_Salon GetSalon() => Query.AsNoTracking().OrderBy(x => x.ID).FirstOrDefault()!;
    public bool AddSalon(Tbl_Salon salon) => Insert(salon);
    public bool EditSalon(Tbl_Salon salon) => Modify(salon);
}

/// <summary>دسته بندی خدمات</summary>
public class CategoryService : BaseRepository<Tbl_Category>, ICategoryService
{
    public CategoryService(DatabaseContext db) : base(db) { }

    public List<Tbl_Category> GetCategories() => GetAll();
    public Tbl_Category GetCategoryByTC(string tc) => GetByTc(tc)!;
    public List<Tbl_Category> SearchCategories(string search)
        => Query.AsNoTracking().Where(x => x.CategoryName.Contains(search)).ToList();
    public List<Tbl_Category> GetCategoriesBySalonTC(string salonTC)
        => Guid.TryParse(salonTC, out var g) ? Query.AsNoTracking().Where(x => x.SalonTC == g).ToList() : new();
    public bool AddCategory(Tbl_Category category) => Insert(category);
    public bool EditCategory(Tbl_Category category) => Modify(category);
    public bool DeleteCategory(string tc) => SoftDelete(tc);
}

/// <summary>خدمات سالن</summary>
public class SalonServiceService : BaseRepository<Tbl_SalonSerice>, ISalonServiceService
{
    public SalonServiceService(DatabaseContext db) : base(db) { }

    public List<Tbl_SalonSerice> GetServices() => GetAll();
    public Tbl_SalonSerice GetServiceByTC(string tc) => GetByTc(tc)!;
    public List<Tbl_SalonSerice> GetServicesByCategoryTC(string categoryTC)
        => Guid.TryParse(categoryTC, out var g) ? Query.AsNoTracking().Where(x => x.CategoryTC == g).ToList() : new();
    public List<Tbl_SalonSerice> SearchServices(string search)
        => Query.AsNoTracking().Where(x => x.ServiceName.Contains(search) || (x.Description ?? "").Contains(search)).ToList();
    public bool AddService(Tbl_SalonSerice service) => Insert(service);
    public bool EditService(Tbl_SalonSerice service) => Modify(service);
    public bool DeleteService(string tc) => SoftDelete(tc);
}

/// <summary>شبکه های اجتماعی سالن</summary>
public class SocialService : BaseRepository<Tbl_Social>, ISocialService
{
    public SocialService(DatabaseContext db) : base(db) { }

    public List<Tbl_Social> GetSocialMedias() => GetAll();
    public bool AddSocialMedia(Tbl_Social socialMedia) => Insert(socialMedia);
    public bool EditSocialMedia(Tbl_Social socialMedia) => Modify(socialMedia);
}

/// <summary>خبر روز</summary>
public class NewsDayService : BaseRepository<Tbl_NewsDay>, INewsDayService
{
    public NewsDayService(DatabaseContext db) : base(db) { }

    public Tbl_NewsDay GetNewsDay()
        => Query.AsNoTracking().OrderByDescending(x => x.RegisterData).FirstOrDefault()!;
    public bool AddNewsDay(Tbl_NewsDay newsDay) => Insert(newsDay);
    public bool EditNewsDay(Tbl_NewsDay newsDay) => Modify(newsDay);
}
